<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Website Builder 404</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name=“theme-color” content="#F2F3F6">
        <meta property="og:title" content="Website Builder 404" />
        <meta property="og:description" content="Oooops, looks like the page you requested could not be found. Please check the URL for proper spelling and capitalization." />
        <link rel="canonical" href="https://hostinger.com/">
        <link rel="icon" type="image/png" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAAsSAAALEgHS3X78AAAA+ElEQVRYhe2XvRWDIBRGb3IygGmpHEEHsMg01BnHaSxcwBGsaOMIaTjEvwd6DmoKvlJ93MtTjgAX5xZ6QFcmr1vVC/cyoNjJ7MfjPQLwAmiApwBvdgp0wGt84b4BnsWE160adGUyXZlcFDgabuvXBU6Cu/qJwNnwicAVcCdgP4hVuM0hcPgtw9wDp25VuQPusqVz4jKMlGDnjhYIvrajBYJJAkkgCSSBLQLdlQKLPVzs+Dalm3+pnnopA9CD3IEYcKlzgx1bFIgCr1s1eOCuO3OBU+FzgdPhY4H+CjjMzoax4boyHx8clsswA9474ACdMHOAUjrY/k2+tzawcgMkVDsAAAAASUVORK5CYII=" />
        <link href="https://fonts.googleapis.com/css?family=Inter:400,600&display=swap" rel="stylesheet">
        <style>
            *,
            :after,
            :before {
                margin: 0;
                padding: 0;
                box-sizing: border-box
            }
            a,
            body,
            div,
            em,
            h1,
            html,
            img,
            p {
                margin: 0;
                padding: 0;
                border: 0;
                font-size: 100%;
                font: inherit;
                vertical-align: baseline
            }
            :focus {
                outline: 0
            }
            body {
                line-height: 1;
                -webkit-font-smoothing: antialiased;
                word-wrap: wrap;
                cursor: default
            }
            [hidden] {
                display: none
            }

            html {
                font-size: 100%;
                -webkit-text-size-adjust: 100%;
                -ms-text-size-adjust: 100%
            }

            img {
                width: 100%;
                max-width: 190px;
                height: auto;
                border: 0;
            }
            html {
                color: #000;
                background-color: #F2F3F6;
            }

            .chromeframe {
                margin: .2em 0;
                background: #F2F3F6;
                color: #000;
                padding: .2em 0
            }

            .main-404-container {
                width: 100%;
            }

            .wrapper-404 {
                display: flex;
                flex-direction: column;
                max-width: 300px;
                justify-content: center;
                height: 100vh;
                margin: 0 auto;
                align-items: center;
            }

            .title-404, .text-404 {
                font-family: 'Inter', sans-serif;
                text-align: center;
            }

            .title-404 {
                font-weight: 600;
                font-size: 24px;
                margin-top: 40px;
                margin-bottom: 16px;
                line-height: 1.33;
            }

            .text-404 {
                font-size: 14px;
                line-height: 1.72;
            }

            @media screen and (max-width: 767px){
                img {
                    max-width: 160px;
                }

                .title-404 {
                    margin-top: 32px;
                }
            }
 

        </style>
    </head>
    <body>
        <main class="main-404-container">
            <div class="wrapper-404">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAXwAAAEECAYAAAArlo9mAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAfESURBVHgB7d1BbhzHGYbh7hERZKmtYwkQTXGf3EA3cXICJyeweYLoCPZJ4hvEe8kaGYKgLLUWoulMC+lACRzONDk9XVXf82xISMVa/IsXjWGzqn/56u3QAdC8TQdABMEHCCH4ACEEHyCE4AOEEHyAEIIPEOLi0IKnX33ZdwAU79DfVXnCBwgh+AAhBB8ghOADhBB8gBCCDxBC8AFCCD5ACMEHCCH4ACEEHyCE4AOEOHh4GkDJttvtw13322+GYfhj1w1Pxn/ru+6nYeh+erDZ3FxefvG6u4Pa9j1Gf+h0NadlAqXa/vLu693H3fN9xB7+nyXvh6G/ub763fNuhtr2nTgtE2jS9pd/fPPx4+77W+I5etj3w1/H0HaN7juHJ3ygOtvtuye7Yff3A/H83PsH/YfLvfct7fu/POEDzfm42307I56jh//c/ebPhxbVtu9cgg9UZ/+xx++7mfq++/rwmrr2nUvwgeoMXT87oHtPDi2obd+5BB8ghOADFepfdzON77ofsep1N9O6+84j+EB1hmH4oZtp6A8HtLZ95xJ8oDoXmw/P90/AR7+yOK590G1uWtt3LsEHqjO+nz70w1+OXb8bhqOOLKht37kEH6jS08tH3/f7iN725Pzp//rhT9dXj44+qqC2fecQfKBaV5ePnm/6zR923fDDf/+Ss389DLubTf/hcgxtN1Nt+x7L0QoAjXC0AgCfCD5ACMEHCCH4ACEEHyCE4AOEEHyAEIIPEELwAUIIPkAIwQcIIfgAIQ4engZAGzzhA4QQfIAQgg8QQvABQgg+QAjBBwgh+AAhLg4tcIk5QB1cYg7AJ4IPEELwAUIIPkAIwQcIIfgAIQQfIITgA4QQfIAQgg8QQvABQgg+QAjBBwgh+AAhBB8ghOADhBB8gBCCDxBC8AFCCD5ACMEHCCH4ACEEHyCE4AOEEHyAEIIPEELwAUIIPkAIwQcIIfgAIQQfIITgA4QQfIAQgg8QQvABQgg+QAjBBwgh+AAhBB8ghOADhBB8gBCCDxBC8AFCCD5ACMEHCCH4ACEEHyCE4AOEEHyAEIIPEELwAUIIPkAIwQcIIfgAIQQfIITgA4QQfIAQgs/Zvdi+e9aFMwPWIPic1c/bd9/2w+5v49culBmwFsHnbMbADcPuu/H78Wti8MyANQk+Z/F56CZpwTMD1ib4LO7XQjdJCZ4ZUALBZ1G3hW7SevDMgFIIPos5JnSTVoNnBpRE8FnEi+2bZ8eGbtJa8ObEfjKuH2fXwQIEn0VcXz7+cR+vm26mVqJ/l9iPxpmNs+tgAYLPYq6vHn+XGP17xX4/sw4WIvgsKi36Yk/JBJ/FpURf7Cmd4HMWrUdf7KmB4HM2rUZf7KmF4HNWrUVf7KmJ4HN2rURf7KmN4LOK2qMv9tRI8FlNrdEXe2ol+KyqtuiLPTUTfFZXS/TFntoJPkUoPfpiTwsEn2KUGn2xpxWCT1FKi77Y0xLBpzilRF/saY3gU6S1oy/2tEjwKdZa0Rd7WiX4FO3c0Rd7Wib4FO9c0Rd7Wif4VGHp6Is9CQSfaiwVfbEnheBTlVNHX+xJIvhU51TRF3vSXHRQoTG4L35+0/X9ZtabOP+O/n++72YSe2om+FTrPtHv7kDsqZ2PdKjaXT/emUvsaYHgU72loy/2tELwacJS0Rd7WiL4NOPU0Rd7WiP4NOVU0Rd7WiT4NOe+0Rd7WiX4NGmzuRi6O7rPz0LJBJ/m3PUvaCdLXZcIaxN8mnLf2E9EnxYJPs04Vewnok9rBJ8mnDr2E9GnJYJP9ZaK/UT0aYXgU7WlYz8RfVog+FTrPufZn/NidCiF45Gp0ikuL7nPefpXl18sfkInnJonfKpzqpuqlr4YHUoj+FTl1NcSij5JBJ9qLHUHreiTQvCpwtIXjos+CQSf4i0d+4no0zrBp2jniv1E9GmZ4FOsc8d+Ivq0SvAp0lqxn4g+LRJ8irN27CeiT2sEn6KUEvuJ6NMSwacYpcV+Ivq0QvApQqmxn4g+LRB8Vld67CeiT+0En1XVEvuJ6FMzwWc1tcV+IvrUSvBZRa2xn4g+NRJ8zq722E9En9oIPmfVSuwnok9NBJ+zaS32E9GnFoLPWbQa+4noUwPBZ3Gtx34i+pRO8FlUSuwnok/JBJ/FpMV+IvqUSvBZxIvtm2eJsZ/cJ/rj7DpYgOCziOvLxz/ODV4rsZ/cJfqfZrCfXQcLEHwWMyd4rcV+YgaURPBZ1DHBaz10ZkApBJ/F3Ra8lNCZASUQfM7i14KXFjozYG2Cz9l8HrzU0JkBa+pfvno73Lbg6Vdf9h2c0PjaYfqbKGbAEg71XPABGnGo5z7SAQgh+AAhBB8ghOADhBB8gBCCDxBC8AFCCD5ACMEHCCH4ACEEHyCE4AOEEHyAEIIPEELwAUIIPkAIwQcIIfgAIQQfIITgA4QQfIAQgg8QQvABQgg+QAjBBwgh+AAhBB8ghOADhBB8gBCCDxBC8AFCCD5ACMEHCCH4ACEEHyCE4AOEEHyAEIIPEELwAUIIPkAIwQcIIfgAIQQfIITgA4QQfIAQgg8QQvABQgg+QAjBBwgh+AAhBB8ghOADhBB8gBCCDxBC8AFCCD5ACMEHCNG/fPV26ABonid8gBCCDxBC8AFCCD5ACMEHCCH4ACEEHyDEvwDZf3Iik87FngAAAABJRU5ErkJggg==" alt="a computer screen with a cross - stitch pattern"/>
            <p class="title-404"> Page not found </p>
            <p class="text-404"> This could be because the page URL is incorrect or the page you are looking for does not exist. </p>
            </div>
        </main>
    </body>
</html>
